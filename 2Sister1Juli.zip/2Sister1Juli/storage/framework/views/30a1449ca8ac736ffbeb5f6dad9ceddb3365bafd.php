

<?php $__env->startSection('title', "Daftar Pegawai"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <a class="btn btn-success" href="<?php echo e(url('/admin/pegawai/add')); ?>">Tambah</a>
        <div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <!-- <th>NO</th> -->
                            <th>NIP</th>
                            <th>NIK</th>
                            <th>NAMA</th>
                            <th>DEPT</th>
                            <th>JABATAN</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td></td> -->
                            <td><?php echo e($p->nip); ?></td>
                            <td><?php echo e($p->nik); ?></td>
                            <td><?php echo e($p->nama); ?></td>
                            <td><?php echo e($p->id_dept); ?></td>
                            <td><?php echo e($p->jabatan); ?></td>
                            <td style="width: 200px">
                                <a class="btn btn-primary" href="<?php echo e(url('/admin/pegawai/update/' . $p -> nip)); ?>">Edit</a>
                                <a class="btn btn-danger" onclick="return confirm('Anda yakin menghapus ')" href="<?php echo e(url('/admin/pegawai/delete/' . $p -> nip)); ?>">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/pegawai/index.blade.php ENDPATH**/ ?>
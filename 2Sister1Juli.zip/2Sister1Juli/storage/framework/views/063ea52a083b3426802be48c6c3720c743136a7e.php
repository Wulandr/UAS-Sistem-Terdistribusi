<?php echo $__env->make('backend/user/style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>INFORMASI WISUDA</title>
<?php echo $__env->make('backend/user/navbar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="contact" class="contact-us section">
    <div class="container">

        <div class="row">
            <div class="col-lg-6 align-self-center wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.25s">
                <div class="section-heading">
                    <h2>Mata Kuliah Favorit Mahasiswa Universitas Januari</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doer ket eismod tempor incididunt ut labore et dolores</p>
                </div>
            </div>
            <div class="col-lg-6 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.25s">
                <!-- <div class="table-responsive"> -->
                <form id="contact" action="" method="post">
                    <div class="row">
                        <table class="table">
                            <thead>
                                <tr>
                                    <!-- <th>NO</th> -->
                                    <!-- <th>ID</th> -->
                                    <th>NAMA MATA KULIAH</th>
                                    <th>SEMESTER</th>
                                    <th>SKS</th>
                                    <th>KETERANGAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <!-- <td></td> -->
                                    <!-- <td><?php echo e($p->idmakul); ?></td> -->
                                    <td><?php echo e($p->namamakul); ?></td>
                                    <td><?php echo e($p->semester); ?></td>
                                    <td><?php echo e($p->sks); ?></td>
                                    <td><?php echo e($p->keterangan); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>


                        <!-- <div class="col-lg-6">
                            <fieldset>
                                <input type="name" name="name" id="name" placeholder="Name" autocomplete="on" required>
                            </fieldset>
                        </div>
                        <div class="col-lg-6">
                            <fieldset>
                                <input type="surname" name="surname" id="surname" placeholder="Surname" autocomplete="on" required>
                            </fieldset>
                        </div>
                        <div class="col-lg-12">
                            <fieldset>
                                <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
                            </fieldset>
                        </div>
                        <div class="col-lg-12">
                            <fieldset>
                                <textarea name="message" type="text" class="form-control" id="message" placeholder="Message" required=""></textarea>
                            </fieldset>
                        </div>
                        <div class="col-lg-12">
                            <fieldset>
                                <button type="submit" id="form-submit" class="main-button ">Send Message</button>
                            </fieldset>
                        </div> -->
                    </div>
                    <div class="contact-dec">
                        <img src="<?php echo e(asset('user/assets/images/contact-decoration.png')); ?>" alt="">
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<?php echo $__env->make('backend/user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/user/akademik.blade.php ENDPATH**/ ?>
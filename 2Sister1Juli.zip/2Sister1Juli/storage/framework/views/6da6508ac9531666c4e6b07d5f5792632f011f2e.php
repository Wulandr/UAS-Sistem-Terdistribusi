

<?php $__env->startSection('title', "Daftar Mahasiswa"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <a class="btn btn-success" href="<?php echo e(url('/admin/mahasiswa/add')); ?>">Tambah</a>
        <div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <!-- <th>NO</th> -->
                            <th>NIM</th>
                            <th>NAMA MAHASISWA</th>
                            <th>TELEPON</th>
                            <th>EMAIL</th>
                            <th>ALAMAT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td></td> -->
                            <td><?php echo e($p->nim); ?></td>
                            <td><?php echo e($p->nama); ?></td>
                            <td><?php echo e($p->telp); ?></td>
                            <td><?php echo e($p->email); ?></td>
                            <td><?php echo e($p->alamat); ?></td>
                            <td style="width: 200px">
                                <a class="btn btn-primary" href="<?php echo e(url('/admin/mahasiswa/update/' . $p -> nim)); ?>">Edit</a>
                                <a class="btn btn-danger" onclick="return confirm('Anda yakin menghapus ')" href="<?php echo e(url('/admin/mahasiswa/delete/' . $p -> nim)); ?>">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/mahasiswa/index.blade.php ENDPATH**/ ?>
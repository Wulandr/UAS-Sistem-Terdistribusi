

<?php $__env->startSection('title', "Daftar Kelas"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <a class="btn btn-success" href="<?php echo e(url('/admin/kelas/add')); ?>">Tambah</a>
        <div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <!-- <th>NO</th> -->
                            <th>ID</th>
                            <th>NAMA KELAS</th>
                            <th>ID TAHUN AJAR</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td></td> -->
                            <td><?php echo e($p->idkelas); ?></td>
                            <td><?php echo e($p->namakelas); ?></td>
                            <td><?php echo e($p->idthnajar); ?></td>
                            <td style="width: 200px">
                                <a class="btn btn-primary" href="<?php echo e(url('/admin/kelas/update/' . $p -> idkelas)); ?>">Edit</a>
                                <a class="btn btn-danger" onclick="return confirm('Anda yakin menghapus ')" href="<?php echo e(url('/admin/kelas/delete/' . $p -> idkelas)); ?>">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/kelas/index.blade.php ENDPATH**/ ?>
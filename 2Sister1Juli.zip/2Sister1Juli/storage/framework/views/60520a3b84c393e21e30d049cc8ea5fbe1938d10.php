

<?php $__env->startSection('title', "Update Kelas"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="container">
        <?php if(session("success")): ?>
        <div class="alert alert-primary"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo implode('', $errors->all('<li>:message</li>')); ?>

        </div>
        <?php endif; ?>
        <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/kelas/update/' . $kelas -> idkelas)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="control-label col-sm-2">ID KELAS:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="idkelas" value="<?php echo e($kelas -> idkelas); ?>" name="idkelas" readonly />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">NAMA KELAS:</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="namakelas" value="<?php echo e($kelas -> namakelas); ?>" name="namakelas">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">ID TAHUN AJAR</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="idthnajar" value="<?php echo e($kelas -> idthnajar); ?>" name="idthnajar">
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Perbarui</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/kelas/update.blade.php ENDPATH**/ ?>
 <!-- Scripts -->
 <script src="<?php echo e(asset('user/vendor/jquery/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('user/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(asset('user/assets/js/owl-carousel.js')); ?>"></script>
 <script src="<?php echo e(asset('user/assets/js/animation.js')); ?>"></script>
 <script src="<?php echo e(asset('user/assets/js/imagesloaded.js')); ?>"></script>
 <script src="<?php echo e(asset('user/assets/js/templatemo-custom.js')); ?>"></script>

 </body>

 <footer>
     <div class="container">
         <div class="row">
             <div class="col-lg-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.25s">
                 <p>© Copyright 2021 Space Dynamic Co. All Rights Reserved.

                     <br>Design: <a rel="nofollow" href="https://templatemo.com">TemplateMo</a>
                     <br>Project by: <a rel="nofollow" href="">2-Tim Berners-Lee</a>
                 </p>
             </div>
         </div>
     </div>
 </footer><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/user/footer.blade.php ENDPATH**/ ?>
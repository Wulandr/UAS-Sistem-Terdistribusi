

<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Departemen <a href="<?php echo e(url('/admin/departemen/create')); ?>" class="btn btn-primary btn-xs" title="Tambah Departemen Baru"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a></h1>
    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>No</th><th> No Departemen </th><th> Nama Departemen </th><th>Aksi</th>
                </tr>
            </thead>            
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-Perkuliahan\Sistem Terdistribusi\SourceCode\Sister_v0.1\resources\views/backend/departemen/index.blade.php ENDPATH**/ ?>
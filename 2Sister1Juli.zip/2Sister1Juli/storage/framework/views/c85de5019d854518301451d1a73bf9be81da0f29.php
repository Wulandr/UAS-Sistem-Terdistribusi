

<?php $__env->startSection('title', "Update Nilai"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="container">
        <?php if(session("success")): ?>
        <div class="alert alert-primary"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo implode('', $errors->all('<li>:message</li>')); ?>

        </div>
        <?php endif; ?>
        <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/nilai/update/' . $nilai -> nim)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="control-label col-sm-2">NIM:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="nim" value="<?php echo e($nilai -> nim); ?>" name="nim" readonly />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">MATA KULIAH :</label>
                <div class="col-sm-3">
                    <select name="idmakul" id="idmakul" class="form-control">
                        <option value="ST">Sistem Terdistribusi</option>
                        <option value="PST">Praktikum Sistem Terdistribusi</option>
                        <option value="PWL">Pemrogaman Web Lanjut</option>
                        <option value="PPWL">Praktikum Pemrogaman Web Lanjut</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">TAHUN AJAR :</label>
                <div class="col-sm-3">
                    <select name="idthnajar" id="idthnajar" class="form-control">
                        <option value="1">2018</option>
                        <option value="2">2019</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">KELAS :</label>
                <div class="col-sm-3">
                    <select name="idkelas" id="idkelas" class="form-control">
                        <option value="1">TI B</option>
                        <option value="2">TI D</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">UK1:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="uk1" value="<?php echo e($nilai -> uk1); ?>" name="uk1" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">UK2:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="uk2" value="<?php echo e($nilai -> uk2); ?>" name="uk2" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">UTS:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="uts" value="<?php echo e($nilai -> uts); ?>" name="uts" />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">UAS:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="uas" value="<?php echo e($nilai -> uas); ?>" name="uas" />
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Perbarui</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/nilai/update.blade.php ENDPATH**/ ?>
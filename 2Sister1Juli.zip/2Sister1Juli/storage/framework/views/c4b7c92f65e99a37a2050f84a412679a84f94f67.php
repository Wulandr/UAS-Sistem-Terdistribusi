

<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Pekerja Proyek <a href="<?php echo e(url('/admin/pekerja_proyek/add')); ?>" class="btn btn-primary btn-xs" title="Tambah Pekerja Proyek Baru"><span class="glyphicon glyphicon-plus" aria-hidden="true" /></a></h1>
    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Id Proyek</th>
                    <th>NIP</th>
                    <th>Waktu</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/pekerja_proyek/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Proyek <a href="<?php echo e(url('/admin/proyek/create')); ?>" class="btn btn-primary btn-xs" title="Tambah Proyek Baru"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a></h1>
    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>No</th><th> No Proyek </th><th> Nama Proyek </th><th>Aksi</th>
                </tr>
            </thead>            
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/proyek/index.blade.php ENDPATH**/ ?>
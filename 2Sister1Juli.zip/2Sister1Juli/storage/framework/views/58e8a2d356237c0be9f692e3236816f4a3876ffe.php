

<?php $__env->startSection('title', "Update Mata Kuliah"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="container">
        <?php if(session("success")): ?>
        <div class="alert alert-primary"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo implode('', $errors->all('<li>:message</li>')); ?>

        </div>
        <?php endif; ?>
        <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/matakuliah/update/' . $matakuliah -> idmakul)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="control-label col-sm-2">ID MAKUL:</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="idmakul" value="<?php echo e($matakuliah -> idmakul); ?>" name="idmakul" readonly />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">NAMA MATA KULIAH:</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="namamakul" value="<?php echo e($matakuliah -> namamakul); ?>" name="namamakul">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">SEMESTER</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="semester" value="<?php echo e($matakuliah -> semester); ?>" name="semester">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">SKS</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="sks" value="<?php echo e($matakuliah -> sks); ?>" name="sks">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">KETERANGAN</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="keterangan" value="<?php echo e($matakuliah -> keterangan); ?>" name="keterangan">
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Perbarui</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/matakuliah/update.blade.php ENDPATH**/ ?>
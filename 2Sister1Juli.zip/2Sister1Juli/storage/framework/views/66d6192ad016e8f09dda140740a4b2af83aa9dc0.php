<div class="col-sm-12">
  <p class="back-link">Lumino Theme by <a href="https://www.medialoot.com">Medialoot</a></p>
</div>
<?php /**PATH D:\01-Perkuliahan\Sistem Terdistribusi\SourceCode\Sister_v0.1\resources\views/backend/admin/footer.blade.php ENDPATH**/ ?>
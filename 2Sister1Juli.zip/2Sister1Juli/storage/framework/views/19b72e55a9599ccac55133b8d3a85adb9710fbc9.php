

<?php $__env->startSection('title', "Tambah Kelas"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="container">
        <?php if(session("success")): ?>
        <div class="alert alert-primary"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo implode('', $errors->all('<li>:message</li>')); ?>

        </div>
        <?php endif; ?>
        <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/kelas/add')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label class="control-label col-sm-2">ID KELAS:</label>
                <!--NAMA PEGAWAI-->
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="idkelas" placeholder="ID Kelas" name="idkelas">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">NAMA KELAS:</label>
                <!--NAMA PEGAWAI-->
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="namakelas" placeholder="Nama Kelas" name="namakelas">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2">ID TAHUN AJAR :</label>
                <!-- <div class="col-sm-4">
                    <input type="text" class="form-control" id="idthnajar" placeholder="ID TAHUN AJAR" name="idthnajar">
                </div> -->
                <div class="col-sm-3">
                    <select name="idthnajar" id="idthnajar" class="form-control">
                        <?php $__currentLoopData = $thnajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->idthnajar); ?>"> <?php echo e($p->ket); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Tambah</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 4\Laravel pak pii\Sister_v0.1\resources\views/backend/kelas/add.blade.php ENDPATH**/ ?>